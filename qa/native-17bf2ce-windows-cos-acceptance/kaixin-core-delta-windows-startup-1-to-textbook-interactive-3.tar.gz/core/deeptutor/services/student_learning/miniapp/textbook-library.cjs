const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const {DatabaseSync} = require('node:sqlite');
const {performance} = require('node:perf_hooks');
const {terms, contentHash} = require('./retrieval.cjs');
const segmenter = new Intl.Segmenter('zh-CN', {granularity: 'word'});
const subjects = new Set(['chinese', 'math', 'english', 'physics', 'chemistry', 'biology', 'history', 'geography', 'ethics', 'politics']);
const volumes = new Set(['上册', '下册', '全册']);
const seniorVolumes = new Set(['全册', '必修上册', '必修下册', ...['第一册', '第二册', '第三册', '第四册'].flatMap(v => ['必修' + v, '选择性必修' + v]), ...['上册', '中册', '下册'].map(v => '选择性必修' + v)]);
const stageOf = m => m.stage || (m.grade > 6 ? '初中' : '小学');
function validMetadata(m) {
  if (!m || !subjects.has(m.subject)) return false;
  if (m.stage === '高中') return m.grade === null && m.subject !== 'ethics' && seniorVolumes.has(m.volume);
  return m.subject !== 'politics' && Number.isInteger(m.grade) && m.grade >= 1 && m.grade <= 9 && volumes.has(m.volume) && (!m.stage || m.stage === (m.grade > 6 ? '初中' : '小学'));
}
const hashId = /^[a-f0-9]{64}$/;
const tokenText = text => [...segmenter.segment(text.normalize('NFKC').toLowerCase())].filter(p => p.isWordLike).map(p => p.segment).join(' ');
const schema = `CREATE TABLE meta(key TEXT PRIMARY KEY,value TEXT NOT NULL);
  CREATE TABLE books(id TEXT PRIMARY KEY, data TEXT NOT NULL);
  CREATE TABLE excerpts(id INTEGER PRIMARY KEY, book_id TEXT NOT NULL, subject TEXT NOT NULL,
    grade INTEGER, approved INTEGER NOT NULL, data TEXT NOT NULL);
  CREATE VIRTUAL TABLE lookup USING fts5(scope,tokens);`;

// This index is a local review artifact. Only explicitly reviewed excerpts enter answer search.
function buildTextbookIndex(root, destination) {
  const catalog = JSON.parse(fs.readFileSync(path.join(root, 'catalog.json'), 'utf8'));
  const reviewPath = path.join(root, 'reviews.json');
  const reviews = fs.existsSync(reviewPath) ? JSON.parse(fs.readFileSync(reviewPath, 'utf8')) : {schemaVersion: 1, passages: []};
  if (catalog.schemaVersion !== 1 || !Array.isArray(catalog.books) || reviews.schemaVersion !== 1 || !Array.isArray(reviews.passages)) throw Error('教材目录或核对记录格式不正确');
  const temporary = destination + '.' + crypto.randomUUID() + '.tmp';
  const db = new DatabaseSync(temporary);
  const counts = {books: 0, pages: 0, reviewedPassages: 0};
  try {
    db.exec(schema + 'BEGIN;');
    const insertBook = db.prepare('INSERT INTO books VALUES (?,?)');
    const insertExcerpt = db.prepare('INSERT INTO excerpts(book_id,subject,grade,approved,data) VALUES (?,?,?,?,?)');
    const insertTokens = db.prepare('INSERT INTO lookup(rowid,scope,tokens) VALUES (?,?,?)');
    const add = (book, passage, approved) => {
      const result = insertExcerpt.run(book.id, book.metadata.subject, book.metadata.grade, approved ? 1 : 0, JSON.stringify(passage));
      insertTokens.run(result.lastInsertRowid, approved ? 'reviewed' : 'raw', tokenText([passage.chapter || '', ...(passage.topics || []), passage.text].join('\n')));
    };
    const ids = new Set();
    for (const book of catalog.books) {
      if (!hashId.test(book.id) || ids.has(book.id) || !validMetadata(book.metadata)) throw Error('请先核对教材身份：' + book.filename);
      ids.add(book.id);
      if (book.supersededBy != null) {
        const replacement = catalog.books.find(b => b.id === book.supersededBy);
        if (!replacement || replacement.id === book.id || replacement.supersededBy || !replacement.identityConfirmed || stageOf(replacement.metadata) !== stageOf(book.metadata) || (replacement.metadata.resourceKind || 'textbook') !== (book.metadata.resourceKind || 'textbook') || ['subject', 'grade', 'volume', 'publisher'].some(key => replacement.metadata?.[key] !== book.metadata[key])) throw Error('替换教材身份不一致或替换链未整理：' + book.filename);
      }
      insertBook.run(book.id, JSON.stringify(book)); counts.books++;
      const folder = path.join(root, 'pages', book.id), pages = new Map();
      for (const file of fs.readdirSync(folder).filter(n => /^\d{4}\.json$/.test(n)).sort()) {
        const page = JSON.parse(fs.readFileSync(path.join(folder, file), 'utf8'));
        if (page.sourceHash !== book.id || page.pdfPage !== Number(file.slice(0, 4))) throw Error('页来源不匹配：' + file);
        pages.set(page.pdfPage, page);
        if (['native', 'ocr'].includes(page.method) && page.text?.trim()) {
          if (contentHash(page.text) !== page.textHash) throw Error('页文字已变化，请重新核对：' + file);
          add(book, {pdfPages: [page.pdfPage], printedPages: [], text: page.text, textHash: page.textHash,
            method: page.method, warnings: page.warnings || [], reviewStatus: 'unreviewed'}, false);
          counts.pages++;
        }
      }
      for (const review of reviews.passages.filter(p => p.bookId === book.id)) {
        if (!book.identityConfirmed || review.status !== 'verified' || typeof review.text !== 'string' || !review.text.trim() || review.text.length > 6000 || !Array.isArray(review.evidence) || !review.evidence.length || !Array.isArray(review.topics) || !review.topics.length || review.topics.some(t => typeof t !== 'string' || t.trim().length < 2 || t.length > 80) || typeof review.chapter !== 'string') throw Error('已核对片段的证据或内容不完整');
        for (const evidence of review.evidence) {
          const page = pages.get(evidence.pdfPage);
          if (!page || !page.textHash || page.textHash !== evidence.textHash) throw Error('核对记录已失效：教材页已变化');
        }
        if (!Array.isArray(review.printedPages) || review.printedPages.length > review.evidence.length || review.printedPages.some(p => typeof p !== 'string')) throw Error('教材印刷页码格式不正确');
        const passage = {pdfPages: review.evidence.map(e => e.pdfPage), printedPages: review.printedPages,
          chapter: review.chapter, topics: review.topics, text: review.text, textHash: contentHash(review.text),
          method: 'visually-reviewed-excerpt', contentType: 'source-based-summary', reviewStatus: 'verified', warnings: review.warnings || []};
        add(book, passage, true); counts.reviewedPassages++;
      }
    }
    if (reviews.passages.some(p => !ids.has(p.bookId))) throw Error('核对记录不属于本批教材');
    db.prepare('INSERT INTO meta VALUES (?,?)').run('schemaVersion', '1');
    db.prepare('INSERT INTO meta VALUES (?,?)').run('counts', JSON.stringify(counts));
    db.exec('COMMIT;');
    db.close();
    fs.renameSync(temporary, destination);
    return counts;
  } catch (error) {
    try { db.close(); } catch {}
    fs.rmSync(temporary, {force: true});
    throw error;
  }
}

function openTextbookLibrary(file) {
  const db = typeof file === 'string' ? new DatabaseSync(file, {readOnly: true}) : snapshotDatabase(file);
  if (db.prepare('SELECT value FROM meta WHERE key=?').get('schemaVersion')?.value !== '1') { db.close(); throw Error('教材索引版本不兼容'); }
  const books = new Map(db.prepare('SELECT id,data FROM books').all().map(row => [row.id, JSON.parse(row.data)]));
  const select = db.prepare(`SELECT e.*,lookup.tokens AS search_tokens FROM lookup
    JOIN excerpts e ON e.id=lookup.rowid JOIN books b ON b.id=e.book_id WHERE lookup MATCH ? AND e.approved=?
    AND (?='' OR e.subject=?) AND (?=0 OR e.grade=?) AND (?='' OR e.book_id=?)
    AND (?<>'' OR json_extract(b.data,'$.supersededBy') IS NULL)
    ORDER BY lookup.rank LIMIT 24`);
  function search(query, {subject = '', grade = null, bookId = '', reviewPreview = false, budgetMs = 80, concepts = []} = {}) {
    if (typeof query !== 'string' || query.length > 20000 || subject && !subjects.has(subject) || grade !== null && (!Number.isInteger(grade) || grade < 1 || grade > 9) || bookId && !hashId.test(bookId) || typeof reviewPreview !== 'boolean' || !Number.isFinite(budgetMs) || budgetMs < 0 || budgetMs > 1000) throw Error('教材检索条件不正确');
    const started = performance.now();
    const empty = status => ({status, matches: [], candidateGrades: [], candidateSubjects: [], studentGradeInferred: false, elapsedMs: performance.now() - started});
    if (!budgetMs) return empty('timeout');
    const normalizedQuery=query.normalize('NFKC').toLowerCase();
    const englishReference = subject === 'english' && !reviewPreview;
    const words = terms(query).filter(w => !['解释', '怎么', '为什么', '学习', '老师', '帮我', '讲解', '题目', '这道题', '问题', '告诉', '知道'].includes(w));
    if (englishReference) {
      for (const word of [...words]) {
        const base = /^([a-z]{2,})['‘’]s$/.exec(word)?.[1];
        if (base && !/^(?:it|he|she|that|what|where|there|here|who|how|let|this)$/.test(base) && !words.includes(base)) words.push(base);
      }
    }
    if (!words.length) return empty('no_match');
    const anchors = (subject || bookId) && Array.isArray(concepts)
      ? concepts.slice(0, 12).filter(value => typeof value === 'string' && value.length >= 3 && value.length <= 40)
        .map(value => value.normalize('NFKC').toLowerCase())
      : [];
    const formula = subject === 'math' && anchors.length
      ? (normalizedQuery.match(/\by\s*=\s*([a-z0-9+\-*^()− ]{4,80})/)?.[1] || '').replace(/[ −]/g, ch => ch === '−' ? '-' : '')
      : '';
    const focus = anchors.length ? words.filter(word => /^[\p{Script=Han}]{2,}$/u.test(word)
      && !anchors.some(anchor => anchor.includes(word))) : [];
    const matchesConcept = (passage, body, focusMatches) => anchors.some(concept =>
      [passage.chapter || '', ...passage.topics].some(value => value.normalize('NFKC').toLowerCase().includes(concept))
      || (focusMatches && body.includes(concept)))
      || (focusMatches && formula && body.replace(/[ −]/g, ch => ch === '−' ? '-' : '').includes(formula));
    const matchesTopic = passage => passage.topics.some(topic => normalizedQuery.includes(topic.normalize('NFKC').toLowerCase()))
      || (passage.topicConjunctions || []).some(group => Array.isArray(group) && group.length >= 2
        && group.every(term => typeof term === 'string' && term.length >= 2 && normalizedQuery.includes(term.normalize('NFKC').toLowerCase())));
    const selectTerms = candidates => {
      const phrases = [...new Set(candidates)].map(word => '"' + word.replaceAll('"', '""') + '"');
      const match = 'scope:' + (reviewPreview ? 'raw' : 'reviewed') + ' AND tokens:(' + phrases.join(' OR ') + ')';
      return select.all(match, reviewPreview ? 0 : 1, subject, subject, grade || 0, grade || 0, bookId, bookId, bookId);
    };
    // Try complete textbook concepts before common words compete for the first 24 places.
    const phrases = [...anchors, formula].filter(Boolean).map(tokenText).filter(Boolean);
    const precise = phrases.length ? selectTerms(phrases).filter(row => {
      const passage = JSON.parse(row.data);
      const body = passage.text.normalize('NFKC').toLowerCase();
      return matchesTopic(passage) || matchesConcept(passage, body, focus.some(word => body.includes(word)));
    }) : [];
    const rows = precise.length ? precise : selectTerms([...words, ...phrases]);
    const topicRows = [], bodyRows = [];
    if (englishReference) for (const row of rows) {
      if (performance.now() - started > budgetMs) return empty('timeout');
      (matchesTopic(JSON.parse(row.data)) ? topicRows : bodyRows).push(row);
    }
    const prioritizedRows = englishReference ? [...topicRows, ...bodyRows] : rows;
    if (anchors.length) {
      for (const row of prioritizedRows) {
        const passage = JSON.parse(row.data);
        const body = passage.text.normalize('NFKC').toLowerCase();
        const heading = [passage.chapter || '', ...passage.topics].join(' ').normalize('NFKC').toLowerCase();
        row.focusMatches = focus.filter(word => body.includes(word)).length;
        row.focusScore = row.focusMatches + 2 * focus.filter(word => heading.includes(word)).length;
        row.inHeading = anchors.some(anchor => heading.includes(anchor));
      }
      prioritizedRows.sort((left, right) => right.focusScore - left.focusScore || right.inHeading - left.inHeading);
    }
    const matches = [], used = new Set(); let size = 0;
    for (const row of prioritizedRows) {
      if (matches.length >= 3) break;
      if (performance.now() - started > budgetMs) break;
      const passage = JSON.parse(row.data), key = row.book_id + ':' + passage.pdfPages.join(',');
      // “分子”也可能是生物学术语；答案来源须匹配已核对的知识点，不靠单个共用词。
      const indexedText = ' ' + row.search_tokens + ' ';
      const matchedTerms = words.filter(word => indexedText.includes(' ' + word + ' '));
      const conceptMatch = matchesConcept(passage, passage.text.normalize('NFKC').toLowerCase(), row.focusMatches);
      const topicMatch = matchesTopic(passage) || conceptMatch;
      // Scoped body matches remain candidates even without a whole topic label.
      const bodyWords = subject === 'english' && !topicMatch ? new Set(tokenText(passage.text).split(' ')) : null;
      const latinBodyTerms = bodyWords ? matchedTerms.filter(word => /^[a-z]{2,}$/.test(word) && bodyWords.has(word)) : [];
      const bodyConcept = (subject && matchedTerms.some(word => /^[\p{Script=Han}]{4,}$/u.test(word) && passage.text.normalize('NFKC').toLowerCase().includes(word)))
        || (latinBodyTerms.length >= 2 && latinBodyTerms.some(word => word.length >= 4));
      if (!reviewPreview && !topicMatch && !bodyConcept) continue;
      if ((!matchedTerms.length && !conceptMatch) || used.has(key)) continue;
      if (size + passage.text.length > 9000) continue;
      const book = books.get(row.book_id);
      if (!reviewPreview && !book.identityConfirmed) continue;
      matches.push({bookId: book.id, title: book.metadata.title || book.filename.replace(/^最新/, '').replace(/\.pdf$/i, ''),
        subject: book.metadata.subject, grade: book.metadata.grade, stage: stageOf(book.metadata), volume: book.metadata.volume,
        publisher: book.metadata.publisher ?? null, series: book.metadata.series ?? null,
        resourceKind: book.metadata.resourceKind || 'textbook',
        edition: book.metadata.edition, approvalYear: book.metadata.approvalYear ?? null,
        provenance: book.provenance || '用户提供原件；出版来源未独立认证', ...passage,
        warnings: [...(book.warnings || []), ...(passage.warnings || [])], matchedTerms});
      used.add(key); size += passage.text.length;
    }
    if (!matches.length && performance.now() - started > budgetMs) return empty('timeout');
    return {status: matches.length ? 'matched' : 'no_match', matches,
      candidateGrades: [...new Set(matches.map(m => m.grade).filter(Number.isInteger))].sort(), candidateSubjects: [...new Set(matches.map(m => m.subject))],
      studentGradeInferred: false, elapsedMs: performance.now() - started};
  }
  function snapshot() {
    return {schemaVersion: 1, books: [...books.values()].map(b => ({id:b.id,identityConfirmed:b.identityConfirmed,
      metadata:{...b.metadata,title:b.metadata.title||b.filename?.replace(/^最新/,'').replace(/\.pdf$/i,'')||b.metadata.subject+' '+b.metadata.grade+'年级'+b.metadata.volume},warnings:b.warnings||[],provenance:b.provenance||'',...(b.supersededBy?{supersededBy:b.supersededBy}:{})})),
      passages:db.prepare('SELECT book_id,data FROM excerpts WHERE approved=1 ORDER BY id').all().map(r=>({bookId:r.book_id,...JSON.parse(r.data)}))};
  }
  return {search, snapshot, close: () => db.close(), counts: JSON.parse(db.prepare('SELECT value FROM meta WHERE key=?').get('counts').value)};
}
function snapshotDatabase(snapshot) {
  if(snapshot?.schemaVersion!==1||!Array.isArray(snapshot.books)||!Array.isArray(snapshot.passages)||snapshot.books.length>300||snapshot.passages.length>20000)throw Error('系统教材格式不正确');
  const db=new DatabaseSync(':memory:');
  try {
    db.exec(schema+'BEGIN;');const books=new Map();
    for(const b of snapshot.books){
      if(!hashId.test(b.id)||books.has(b.id)||!b.identityConfirmed||!validMetadata(b.metadata))throw Error('系统教材身份不正确');
      books.set(b.id,b);db.prepare('INSERT INTO books VALUES (?,?)').run(b.id,JSON.stringify(b));
    }
    for(const b of books.values())if(b.supersededBy){const n=books.get(b.supersededBy);if(!n||n.id===b.id||n.supersededBy||stageOf(n.metadata)!==stageOf(b.metadata)||(n.metadata.resourceKind||'textbook')!==(b.metadata.resourceKind||'textbook')||['subject','grade','volume','publisher'].some(k=>n.metadata[k]!==b.metadata[k]))throw Error('系统教材替换关系不正确');}
    for(const p of snapshot.passages){
      const b=books.get(p.bookId);
      if(!b||p.reviewStatus!=='verified'||typeof p.text!=='string'||!p.text.trim()||p.text.length>6000||contentHash(p.text)!==p.textHash||!Array.isArray(p.topics)||!p.topics.length||p.topics.some(t=>typeof t!=='string'||t.length<2||t.length>80)||!Array.isArray(p.pdfPages)||!p.pdfPages.length||p.pdfPages.some(n=>!Number.isInteger(n)||n<1)||!Array.isArray(p.printedPages)||p.printedPages.some(n=>typeof n!=='string'))throw Error('系统教材片段未核对或已变化');
      const row=db.prepare('INSERT INTO excerpts(book_id,subject,grade,approved,data) VALUES (?,?,?,?,?)').run(b.id,b.metadata.subject,b.metadata.grade,1,JSON.stringify(p));
      db.prepare('INSERT INTO lookup(rowid,scope,tokens) VALUES (?,?,?)').run(row.lastInsertRowid,'reviewed',tokenText([p.chapter||'',...p.topics,p.text].join('\n')));
    }
    db.prepare('INSERT INTO meta VALUES (?,?)').run('schemaVersion','1');
    db.prepare('INSERT INTO meta VALUES (?,?)').run('counts',JSON.stringify({books:books.size,pages:0,reviewedPassages:snapshot.passages.length}));
    db.exec('COMMIT;');return db;
  }catch(error){db.close();throw error;}
}
module.exports = {buildTextbookIndex, openTextbookLibrary, stageOf};

// Local adapter export; retrieval implementation is unchanged.
module.exports.snapshotDatabase = snapshotDatabase;
