"""One bounded original-question lookup, separate from optional teaching links."""
from __future__ import annotations

import re
from dataclasses import dataclass, replace
from urllib.parse import unquote
from time import monotonic

from .reference_task_policy import (
    _OPTIONAL_REFERENCE, _SELECTED_REFERENT, _SOURCE_OPT_OUT, _clauses, _generation, _text,
    ambiguous_practice_action, reference_task_policy,
    refers_to_previous_exercise, requested_practice_variant, selected_practice_topic, student_request,
)
from .textbook_grounding import _only_selected_sources, _scope_text, task_scope

REQUIRED_LOOKUP_SECONDS = 30
_RESOURCE = r'(?:系统默认|系统|默认|内置)?(?:试题库|题库|长期资料库?|资料库?|资源库?|教材库?|课本)(?:里面|里|中|内)?'


def _bank_text(text: str) -> str:
    # A textbook opt-out must neither cancel bank lookup nor become its topic.
    return re.sub(r'(^|[，,。；;\n])\s*(?:不要|不用|不必|别|不需要)\s*(?:再|去)?\s*(?:从|在|按|根据|参考|用|使用|查|检索)?\s*(?:教材库?|课本|(?:(?:我(?:的|上传的)|自己上传的)\s*)?(?:长期)?资料(?:库)?|附件)(?:里面|里|中)?\s*(?:查找|找|选题|出题|选|挑|出)?\s*(?=$|[，,。；;\n])', r'\1', text).strip(' ，,。；;\n')


def explicit_bank(context) -> bool:
    text = _scope_text(_bank_text(student_request(context)))
    return bool(re.search(r'(?:改从|从|在|去|到|按|根据|依据|参考|使用|优先|找).*?(?:题库|试题库)|(?:题库|试题库).*?(?:找|选|出|挑|原题|看看|看一下|搜)', text))


def only_bank_originals(context, request=None) -> bool:
    return bool(re.search(r'(?:只要|只出|只用|只能|仅要|仅限|必须用)\s*(?:系统(?:默认)?|内置|默认)?(?:试题库|题库)(?:里(?:面)?的?)?原题', student_request(context) if request is None else request))


def only_originals(context, request=None) -> bool:
    request = student_request(context) if request is None else request
    return only_bank_originals(context, request) or bool(re.search(
        r'(?:只要|只出|只用|只能|仅要|仅限)\s*(?:(?:我(?:的|上传的)|上传的)?(?:题库|资料|教材)(?:里(?:面的)?|里的|的)?)?原题'
        r'|(?:不要|不接受|不能|别).{0,8}(?:原创|生成新题|编题|改编|新题)',
        request,
    ))


BANK_ADOPTION = "每道实际采用的题库原题，请在开始展示该题时用 Markdown 链接带上给定的完整出处，界面据此直接展示原文和原图。"
ONLY_ORIGINALS_NOTICE = "说明本轮没有找到符合要求的原题。学生只要原题，保留该要求，不自行生成替代。"


def resource_lookup_requested(context) -> bool:
    request = student_request(context)
    if selected_practice_topic(context):
        previous = next((item["content"] for item in reversed(context.conversation_history)
                         if item.get("role") == "user" and isinstance(item.get("content"), str) and not item.get("_context_snapshot")), "")
        request = request + "\n" + previous
    text = _scope_text(_bank_text(_text(request)))
    if only_bank_originals(context, text):
        return True
    for clause in re.split(r'[，,。；;！？!?\n]', text):
        if refers_to_previous_exercise(clause):
            continue
        action = re.search(
            rf'{_RESOURCE}.{{0,18}}(?:查|找|搜|选|挑|出(?:题|\s*[一二两三四五六七八九十几\d]+\s*道)|看看|看\s*$)'
            rf'|(?:查找|检索|搜|翻|找|查).{{0,14}}{_RESOURCE}'
            r'|(?:^|请|帮我|给我|再)\s*(?:找|挑)\s*[一二两三四五六七八九十几\d]*\s*(?:道|组|套)?[^。；;]{0,24}题',
            clause,
        )
        if action and not re.search(r'不要|不用|别|不必|先不|暂不|如何|怎么|怎样|明天|下次', clause[:action.end()]):
            return True
    return False


def bank_scope_allowed(context) -> bool:
    limited = _only_selected_sources(context)
    raw = _scope_text(student_request(context))
    current = _scope_text(_bank_text(raw))
    if limited and resource_lookup_requested(context) and re.search(r'改从|改用|切换到|换到', current) and not re.search(r'(?:只|仅|只能)[^，,。；;\n]*(?:我的|附件|上传|这份|这本|选中|指定)', current):
        limited = False
    if limited:
        return False
    if context.allowed_builtin_tools is not None and 'student_question_sources' not in context.allowed_builtin_tools:
        return False
    if re.search(r'(?:不要|不用|别|不必|不需要)\s*(?:再|去)?(?:查找?|检索|搜索|参考)\s*(?:任何|所有)?\s*(?:资料|资源)(?:库)?\s*(?:$|[，,。；;])', raw):
        return False
    if re.search(r'(?:不要|不用|不必|别|不需要)[^，,。；;\n]{0,8}(?:题库|资料|文件|检索|查找)', current):
        return False
    return True


def _selected_question_source(context) -> bool:
    source = re.compile(
        r'(?:我(?:的|上传)|本人|附件|这篇|这份|所选|指定)[^，,。；;\n]{0,12}(?:题库|资料|文章|文档)|(?:根据|依据|按|照|从)[^，,。；;\n]{0,8}(?:教材|课本|附件|这篇|这份|这一?页|当前页|这本|这(?:道)?题)',
    )
    return any(not (_OPTIONAL_REFERENCE.search(clause) or _SOURCE_OPT_OUT.search(clause))
               and (source.search(clause) or _SELECTED_REFERENT.search(clause)
                    and re.search(r"(?:按|照|依据|依照|根据|用|从).{0,12}(?:引用|所选)", clause))
               for clause in _clauses(_scope_text(_bank_text(student_request(context)))))


def bank_task(context) -> bool:
    if context.active_capability not in {None, '', 'chat', 'deep_solve', 'ask_questions', 'immersive_reading'}:
        return False
    if not bank_scope_allowed(context):
        return False
    # An attachment or open reader only restricts a new exercise when the student uses it as the source.
    if _selected_question_source(context):
        return False
    return reference_task_policy(context).mode == 'question_generation'


def uses_resource_priority(context) -> bool:
    return ((bank_task(context) or resource_lookup_requested(context) and bank_scope_allowed(context))
            and not reference_task_policy(context).mixed_generation)


_TARGET = re.compile(
    r"^(?:(?:请|帮我|带我|教我|我想|我要|想|要|现在|这次|再|继续)\s*)*"
    r"(?:改练|改成|换成|换练|改学|换到|复习|预习|学习|练习|讲解|讲讲|讲一下|解释|学|练)\s*(?:一下\s*)?(.+?)\s*[。！!？?]*$"
)
_CHANGE_TARGET = re.compile(r"(?:从[^，,。；;，！？]+)?(?:换到|改到|切换到|转而练)\s*([^，,。；;！？]+)")
_PAST_STUDY = re.compile(r"(?:刚(?:才)?|之前|上[一节课道次回]+|前面|今天|昨天|课上|课堂).{0,16}(?:讲|学|复习|练)")
_COMBINED = re.compile(r"综合|同时考|结合.{1,26}(?:和|与)|一起考|对比|比较")
_SCOPE_CLAUSE = re.compile(r"^(?:只|仅|只能|不要|不用|不接受|别|必须用).{0,14}(?:题库|教材|资料|附件|原题|原创|改编|编题|新题)")
_FIGURE_FORMAT_CLAUSE = re.compile(r"^(?:(?:请|帮我|给我|并|再|也|要|需要|不用|不要)\s*)*(?:画图|绘图|配图|附图|带图|给一张图)[。！!\s]*$")
_FORMAT_ONLY = re.compile(r"(?:(?:请|我想|想|只要|要|只出|出|给我|改成|做)\s*)*"
                          r"(?:单项选择|多项选择|选择|填空|判断|计算|应用|证明)题")
_PRACTICE_FORMAT = re.compile(
    r"(?:的\s*|(?:[一二两三四五六七八九十\d几]+\s*道|(?:出|来|找|换)\s*个?)\s*"
    r"|(?=(?:单项选择|多项选择|选择|填空|判断|计算|应用|证明)题))"
    r"(?:(?:基础|简单|入门|进阶|稍难|提高)(?:的)?\s*)?"
    r"(单项选择|多项选择|选择|填空|判断|计算|应用|证明)(?:题|(?=\s*$))"
)

def _practice_format(text: str) -> re.Match[str] | None:
    for match in _PRACTICE_FORMAT.finditer(text):
        if match[1] != "选择" or not text[:match.start(1)].rstrip().endswith("自然"):
            return match
    return None


_DIFFICULTY = re.compile(r"基础|简单|入门|中档|中等|进阶|稍难|难一点|难一些|提高|拓展|挑战|难题|压轴")
_PREVIEW_STAGE = re.compile(r"(?:^|[，,。；;\n])\s*(?:(?:请|请你|先|帮我|带我|我想|现在|我们|正在|刚开始|这节课|就是|是来|想要|我|是|还|在)\s*)*预习")
_STOP_PREVIEW = re.compile(r"预习(?:已经)?(?:完|结束)|不再预习|(?:改成|切到|直接)\s*(?:复习|刷题|测验|自测)|已学会|已经学过")
_ADVANCED_DIFFICULTY = {"进阶", "稍难", "提高", "拓展", "挑战", "难题", "压轴"}
PREVIEW_QUESTION_POLICY = (
    "学生在预习。选题以当前已经讲过的一个知识点、可直接完成的一步为准。"
    "先用贴合该阶段的完整原题。仅考点相同的综合题、跨章节题、需要尚未讲解方法的题不要直接作为练习题展示。"
    "若原题有可独立作答的小问，且该小问已经绑定可核对的原题定位与必要共享条件、原图，可以只给这一小问。"
    "没有核对到独立小问时，可以用确有来源的原图和已知条件讲一个基础观察，给来源说明，不把整道综合题作为原题卡插入。"
    "已查完但没有适合预习的原题时，说明本轮找到了偏难题或无合适题。学生允许改编时，可另给一道明确标为改编或原创的基础题，"
    "保留图和改动条件、不给改编题冒用原题链接。学生只要原题或限定题库原题时，保持原件要求，仅提示没有适合的题。"
)

_DISPLAYED_BANK = re.compile(r"\[[^\]\n]*\]\((?:https://deeptutor\.local/library)?#dt-question-([a-f0-9]{64})-([^\s)]+)\)")
_BRIEF_REPLY = re.compile(r"(?:(?:我选)?[A-Da-d]|[+-]?[\d.]+|不知道|没听懂|继续|为什么|谢谢(?:老师)?|明白了|好的)[。!！\s]*")
_ANY_TOPIC = re.compile(r"随便|随机(?:选|找|挑|来|出)|任意(?:一道|出题|挑选|选题)|任选")
_TOPIC_RESET = re.compile(r"^(?:换个?话题|另一个问题)[，,。\s]*")
_FIGURE_PROVENANCE = re.compile(
    r"(?:这(?:一|个|张|幅)?(?:图片|图)|前面(?:这张|那张)?图|刚才(?:这张|那张)?图).{0,16}"
    r"(?:怎么画|怎样画|如何画|哪来|哪儿来|哪来的|哪里来|从哪|来源|命中|图(?:形)?库)"
)


@dataclass(frozen=True)
class PracticeGoal:
    query: str = ""
    subject: str = ""
    grade: int | None = None
    question_format: str = ""
    difficulty: str = ""
    scoped_any: bool = False
    prior_refs: tuple[tuple[str, str], ...] = ()
    source_request: str = ""
    choices: tuple[str, ...] = ()
    preview: bool = False

    @property
    def preview_policy(self) -> str:
        return PREVIEW_QUESTION_POLICY if self.preview and self.difficulty not in _ADVANCED_DIFFICULTY else ""


def _requested_topic(text: str, *, exercise: bool = False) -> str:
    text = _bank_text(text)
    bank_name = _RESOURCE
    # Quotes and later clauses can contain the knowledge point or constraints.
    text = re.sub(r'(?:[，。；;\s]+)?(?:谢谢(?:老师)?|麻烦了|好吗|可以吗|行吗)[。！!？?\s]*$', '', text)
    parts = re.split(r'[，,。；;\n]', text)
    if exercise and parts and not _generation(parts[0]):
        start = next((index for index, part in enumerate(parts) if _generation(part.strip())), 0)
        parts = parts[start:]
    clauses = [part.strip() for part in parts if part.strip()] or [""]
    text = clauses[0].strip()
    if exercise:
        if re.fullmatch(r"(?:我想|我要|想|要)?自测(?:一下)?[。！？!?\s]*", text) or re.fullmatch(
                r"(?:请|帮我|现在|先|再|接着)*\s*讲(?:解)?\s*(?:(?:一|1)?\s*[道个]?\s*)?例题[。！？!?\s]*", text):
            return ""
        text = re.sub(r"^.*?(?:考|测)(?:考|测|一下)?我刚才(?:学|练)的[吗嘛吧！？!?\s]*$", "", text)
        text = re.sub(r"(?:来|让我)?(?:考|测试|检验|测一测|测)(?:考|测|一下)?我?[吗嘛吧。！？!？\s]*$", "", text)
        text = re.sub(r"(?:让我试试|试试我?|练练手|我做做|看看我(?:到底)?会不会|我先试一下)[吗嘛吧！？!?\s]*$", "", text)
    else:
        text = re.sub(r"(?:来)?(?:考|测试|检验|测一测)(?:考)?我[。！？!？\s]*$", "", text)
    text = re.sub(r'^(?:那(?:你)?|好(?:的)?那?)\s*(?=(?:给我|帮我|来|出|找|考))', '', text)
    text = re.sub(rf'^(?:(?:请你?|你能|能不能|能否|帮我|给我|现在|这次|这回|这轮|本次|本轮|再|先|优先|咱们|我们|刚才的内容能|(?:改从|从|去|到|在|参考)?{bank_name}(?:(?:或|和|、){bank_name})*|去)\s*)+', '', text)
    text = re.sub(r'^(?:出|编写|生成|设计|换|挑选?|检索|查找|查|找|搜|来|拿|用|弄|看看|看一下|(?:给|讲(?:解)?)(?=\s*[一二两三四五六七八九十\d几]*\s*[道个题])|选(?=[一二两三四五六七八九十\d几]+\s*(?:道|题|组|套|个)))\s*', '', text)
    text = re.sub(r'^(?:[一二两三四五六七八九十\d几]+\s*(?:道|题|组|套|个)|一些)\s*', '', text)
    if exercise:
        text = re.sub(r"^(?:道|个)(?=\S)|[吗嘛吧！？!?]+$", "", text)
        text = re.sub(r"^(?:中档|中等)(?:难度)?(?:的)?(?=\S)", "", text)
        if text in ("小题", "新题", "试试", "相关的题", "综合题", "综合"):
            text = ""
    text = re.sub(r'^一下\s*', '', text)
    text = re.sub(r'^(?:(?:[一二三四五六七八九十\d]+年级|初[一二三]|[一二三四五六七八九][上下]册?|语文|数学|英语|物理|化学|生物|历史|地理|政治|关于|有关)\s*)+', '', text)
    text = re.sub(r'(?:原题|练习题|练习|试题|题目|题)[。！!？?\s]*$', '', text)
    # Whitespace may be inside a topic such as 自然 选择; require explicit 的.
    # shortcut: retain other format terms until source metadata can verify them.
    text = re.sub(r'的\s*(?:(?:基础|简单|入门|进阶|稍难)(?:的)?\s*)?(?:选择)?$', '', text)
    if (fmt := _practice_format(clauses[0])) and text.endswith(fmt[1]):
        text = re.sub(r"(?:基础|简单|入门|进阶|稍难|提高)?的?\s*" + fmt[1] + r"$", "", text).rstrip()
    if text in {"道", "个", "组", "套"} or re.fullmatch(r"(?:(?:的|跟之前|刚才|前面|上面|同样|同类|同一类|类似|相应|对应|相关|再|继续|接着|随便|任意|一样|一个|一下|题|练习|基础|简单|入门|进阶|稍难|提高|拓展|挑战|单项选择|多项选择|选择|填空|判断|计算|应用|证明)\s*)*", text):
        text = ""
    qualifiers = [part for part in clauses[1:] if not re.fullmatch(rf'\s*(?:改从|从|去|到|在|参考)?{bank_name}\s*', part)
                  and not _SCOPE_CLAUSE.search(part) and not _FIGURE_FORMAT_CLAUSE.fullmatch(part)
                  and not _FORMAT_ONLY.fullmatch(part)
                  and not re.fullmatch(r"(?:请)?(?:保留|给出|标明|附上)(?:原题)?(?:出处|来源)|(?:让)?我(?:来|先|自己)作答", part)]
    return re.sub(r'[\s，。；;！!？?]+', ' ', ' '.join([text, *qualifiers])).strip()[:300] if text else ''




def _explicit_goal(text: str) -> str:
    text = _TOPIC_RESET.sub('', text)
    if match := _CHANGE_TARGET.search(text):
        return _requested_topic(match[1])
    for part in re.split(r'[，,；;\n]', text):
        if match := _TARGET.fullmatch(part.strip()):
            raw = match[1].removesuffix("的内容")
            if part.strip().startswith(("我想改成", "改成", "换成")):
                raw = re.sub(r"^练(?:习)?\s*", "", raw)
            return _requested_topic(raw)
    if match := re.fullmatch(r'(.+?)\s*出\s*(?:一|两|三|几|\d+)?道题[。！!？?\s]*', text):
        return _requested_topic(match[1])
    return ""


def _known_practice_topics(text: str, subject: str = "") -> tuple[str, ...]:
    from .question_topics import intent, taxonomy

    rows = taxonomy()[0]
    return tuple(sorted({rows[key]["label"] for key in intent(text, subject)["topics"]}))


def _refs_from_content(content):
    visible = re.sub(r"```[\s\S]*?```|`[^`\n]*`", "", content)
    return [(unquote(match[2]), match[1]) for match in _DISPLAYED_BANK.finditer(visible)]


def retained_practice_history(rows):
    """Branch-local student words and assistant citations backed by stored source events."""
    from .study_quiz import quiz_invitation, shown_question_stems

    history = []
    for row in rows[-40:]:
        role, content = row.get("role"), row.get("content")
        if not isinstance(content, str):
            continue
        if role == "user":
            history.append({"role": role, "content": content})
        if role != "assistant":
            continue
        visible = set(_refs_from_content(content))
        stems = shown_question_stems(row)
        invitation = quiz_invitation(content) if not stems and not visible else ""
        if not visible and not stems and not invitation:
            continue
        events = row.get("events")
        containers = [row.get("metadata")]
        if isinstance(events, list):
            containers.extend(event.get("metadata") for event in events
                              if isinstance(event, dict) and event.get("type") == "sources")
        refs = []
        for meta in containers:
            if not isinstance(meta, dict) or not isinstance(meta.get("sources"), list):
                continue
            for source in meta["sources"]:
                if not isinstance(source, dict) or source.get("type") != "question_bank":
                    continue
                identity = source.get("qualified_id"), source.get("bank_revision")
                if all(isinstance(value, str) for value in identity) and identity in visible and source.get("reference_used") is True and source.get("related_material") is not True:
                    refs.append(identity)
        if refs or stems or invitation:
            history.append({
                "role": role,
                **({"question_references": list(dict.fromkeys(refs))} if refs else {}),
                **({"quiz_stems": stems} if stems else {}),
                **({"quiz_invitation": invitation} if invitation else {}),
            })
    return history


def practice_goal(context) -> PracticeGoal:
    from deeptutor.visualizers.interactive_math import relative_interactive_request

    from .reference_task_policy import _RECENT_PRACTICE_TOPIC
    from .study_preferences import requests_teaching_figure
    from .study_quiz import ready_for_checkpoint

    checkpoint = ready_for_checkpoint(context)
    request = student_request(context)
    subject, grade = task_scope(context)
    current_subject, current_grade = task_scope(type(context)(user_message=request))
    from_clarification = selected_practice_topic(context)
    variation = requested_practice_variant(context, _text(request))
    current = ("" if checkpoint or variation
               else _explicit_goal(request) or _requested_topic(request, exercise=True))
    if current and context.extension_state.get("question_sources", {}).get("exercise_action"):
        current = " 和 ".join(_known_practice_topics(current, current_subject))
    if from_clarification and _RECENT_PRACTICE_TOPIC.fullmatch(_text(request)):
        current = ""
    any_topic = bool(_ANY_TOPIC.search(request) and (subject or grade is not None))
    if _ANY_TOPIC.search(request):
        current = ""
    elif not current and not checkpoint and not variation:
        named_topics = _known_practice_topics(_text(request), current_subject)
        if len(named_topics) == 1:
            current = named_topics[0]
    known_current = _known_practice_topics(current, current_subject) if current else ()
    joins_topics = re.search(r"和|与|及|并列比较", current)
    choices = known_current if len(known_current) > 1 and not (_COMBINED.search(request) or joins_topics) else ()
    if current and not current_subject and known_current:
        from .question_topics import intent

        inferred = intent(current)["subject"]
        if inferred and inferred != subject:
            subject, grade = inferred, current_grade
    historical = context.metadata.get("practice_history") or context.conversation_history
    prior_goal = prior_request = prior_scope = ""
    preview = bool(_PREVIEW_STAGE.search(_text(request)) and not _STOP_PREVIEW.search(request))
    prior_preview = None
    refs = [ref for item in reversed(historical[-40:]) if item.get("role") == "assistant"
            for ref in item.get("question_references", ())]
    for item in reversed(historical):
        if item.get("role") == "assistant":
            continue
        previous = item.get("content")
        if item.get("role") != "user" or not isinstance(previous, str) or item.get("_context_snapshot") or _BRIEF_REPLY.fullmatch(previous.strip()):
            continue
        if _RECENT_PRACTICE_TOPIC.fullmatch(_text(previous)):
            continue
        prior_context = type(context)(user_message=previous)
        if ambiguous_practice_action(prior_context):
            continue
        if _SCOPE_CLAUSE.search(previous):
            # Scope-only turns affect permission, but carry no new knowledge point.
            prior_scope = prior_scope or previous
            if reference_task_policy(prior_context).mode != "question_generation":
                continue
        declared = _explicit_goal(previous)
        if declared and requests_teaching_figure(previous):
            known = _known_practice_topics(declared, subject)
            if len(known) == 1:
                declared = known[0]
        phase = _PREVIEW_STAGE.search(_text(previous))
        stopped_preview = _STOP_PREVIEW.search(previous)
        if prior_preview is None and (phase or stopped_preview):
            prior_preview = bool(phase and not stopped_preview)
        if not declared and (phase or stopped_preview):
            continue
        generation = reference_task_policy(prior_context).mode == "question_generation"
        if not declared and generation:
            declared = _requested_topic(previous, exercise=True)
            if not declared:
                if not prior_request:
                    prior_request = previous
                continue
        recalled = not declared and bool(_PAST_STUDY.search(previous)) and not refers_to_previous_exercise(previous)
        if recalled:
            known = _known_practice_topics(previous, subject)
            declared = " 和 ".join(known)
        if not declared and not generation and not _TOPIC_RESET.search(previous):
            if _FIGURE_PROVENANCE.search(_text(previous)) or relative_interactive_request(previous):
                continue
            if (requests_teaching_figure(previous) or resource_lookup_requested(prior_context)
                    or re.search(r"第几页|在哪(?:一)?页|在哪(?:一)?章", previous)):
                known = _known_practice_topics(previous, subject)
                if len(known) == 1:
                    declared = known[0]
                    if not current and current_grade is None and grade is not None:
                        # A grade attached to an earlier topic does not constrain a new figure topic.
                        scoped_requests = (item.get("content", "") for item in historical
                                           if item.get("role") == "user" and isinstance(item.get("content"), str))
                        if not any(task_scope(type(context)(user_message=spoken))[1] == grade and (
                            re.match(r"\s*(?:我是|我读|我上|学生是)", spoken) or
                            declared in _known_practice_topics(spoken, subject)
                        ) for spoken in scoped_requests):
                            grade = None
        if declared:
            if not (current or any_topic or _COMBINED.search(request)):
                known = _known_practice_topics(declared, subject)
                if len(known) > 1 and (recalled or not re.search(r"和|与|及|对比", declared)):
                    choices = known
            prior_goal, prior_request = declared, prior_request or previous
            if not (preview or _TOPIC_RESET.search(request) or _STOP_PREVIEW.search(request) or any_topic):
                if not current or _known_practice_topics(current, subject) == _known_practice_topics(declared, subject) and (
                        bool(known_current) or current == declared):
                    preview = prior_preview is True
        elif checkpoint:
            continue
        break
    text = "" if any_topic or choices else current or prior_goal
    if text and not current and not subject:
        from .question_topics import intent

        subject = intent(text)["subject"]
    fmt = _practice_format(request) or _practice_format(prior_request)
    difficulty = ""
    for value in (request, prior_request):
        for match in _DIFFICULTY.finditer(value):
            if re.search(r"(?:别|不|不要|不用|不想|不需要)\s*(?:要|做|来|出|找|选|看)?\s*$", value[:match.start()]):
                difficulty = "基础" if match[0] in _ADVANCED_DIFFICULTY else ""
            else:
                difficulty = match[0]
            if difficulty:
                break
        if difficulty:
            break
    return PracticeGoal(text, subject, grade, fmt[1] if fmt else "选择" if checkpoint else "", difficulty or ("基础" if preview else ""),
                        any_topic, tuple(dict.fromkeys(refs))[:32],
                        request if (current and not from_clarification) or only_originals(context) or re.search(r"改从|改用|只用", request) else prior_scope or prior_request,
                        choices, preview)


def topic(context) -> str:
    return practice_goal(context).query


def _source_goal(context, goal):
    from . import textbooks
    from .question_sources import detail

    meta = context.metadata
    material = meta.get("reading_material_id")
    revision = meta.get("reading_material_revision")
    locator = (meta.get("reading_viewport") or {}).get("locator")
    if material and type(revision) is int and type(locator) is int:
        try:
            store, manifest, book = textbooks._source_page_store(material, revision)
            if 1 <= locator <= manifest.unit_count:
                headings = [item for item in store.outline(material) if 1 <= item.locator <= locator]
                title = ""
                if headings:
                    nearest = max(headings, key=lambda item: (item.locator, item.level))
                    title = re.sub(r"^\s*(?:第[一二三四五六七八九十\d]+[章节课单元]|\d+(?:\.\d+)*[.、．]?)\s*", "", nearest.title).strip()
                if not goal.query and (not title or title in {"目录", "封面", "前言", "复习"}):
                    first = store.unit_text(material, locator).strip().splitlines()
                    if first and 2 <= len(first[0]) <= 24 and re.fullmatch(r"[\u4e00-\u9fffA-Za-z·、－—\s]+", first[0]):
                        title = first[0].strip()
                subjects, grades, _, _ = textbooks._book_parts(manifest.title or manifest.filename)
                subject = (book or {}).get("subject") or (next(iter(subjects)) if len(subjects) == 1 else "")
                grade = (book or {}).get("grade") or (next(iter(grades)) if len(grades) == 1 else None)
                if goal.query or title and title not in {"目录", "封面", "前言", "复习"} and len(title) <= 160:
                    return replace(goal, query=goal.query or title, subject=goal.subject or subject,
                                   grade=goal.grade or (grade if not goal.query and (not goal.subject or goal.subject == subject) else None))
        except (PermissionError, LookupError, OSError, ValueError):
            pass
    for identifier, bank_revision in goal.prior_refs[:3]:
        try:
            body = detail(identifier, revision=bank_revision, surface="chat")
            if body["can_select_original"] and body.get("knowledge_points"):
                label = next((value for value in body["knowledge_points"] if isinstance(value, str) and value.strip()), "")
                label = re.sub(r"^\s*\d+(?:\.\d+)*[.、．]?\s*", "", label).strip()
                if label:
                    return replace(goal, query=label[:160], subject=body["subject"], grade=body.get("grade"))
        except (PermissionError, LookupError, OSError, ValueError):
            continue
    return goal


async def resolve_practice_goal(context, deadline) -> PracticeGoal:
    import asyncio

    goal = practice_goal(context)
    material = context.metadata.get("reading_material_id")
    if goal.scoped_any or goal.choices or goal.query and (not material or goal.subject):
        return goal
    if not material and not goal.prior_refs:
        return goal
    return await asyncio.wait_for(asyncio.to_thread(_source_goal, context, goal), max(0, deadline - monotonic()))


async def lookup(context, query_text: str, deadline: float, *, include_visual: bool, goal=None, original_only=False) -> dict:
    from .question_sources import query

    goal = goal or practice_goal(context)
    choice_requested = goal.question_format.endswith("选择")
    original_only = original_only or only_originals(context, goal.source_request)
    filters = dict(subject=goal.subject, grade=goal.grade, query=query_text, include_visual=include_visual,
                   choice_only=choice_requested and original_only, require_viewable=True)
    if choice_requested and not original_only:
        filters["prefer_choice"] = True
    if goal.preview_policy:
        filters["preview_only"] = True
    if goal.prior_refs:
        filters["skip_question_ids"] = tuple(identifier for identifier, _ in goal.prior_refs)
    return await query(context, deadline, **filters)


async def seed(context, stream, *, source, stage) -> str:
    if not bank_task(context):
        return ''
    state = context.extension('question_sources')
    if state.get('lookup_complete'):
        return state.get('seed_block', '')

    required = explicit_bank(context)
    started = monotonic()
    deadline = started + (REQUIRED_LOOKUP_SECONDS if required else 1)
    from .textbook_grounding import CLARIFY_PRACTICE_GOAL, INCOMPLETE_RESOURCE_LOOKUP
    try:
        goal = await resolve_practice_goal(context, deadline)
    except TimeoutError:
        return INCOMPLETE_RESOURCE_LOOKUP
    if not goal.query and not goal.scoped_any:
        return CLARIFY_PRACTICE_GOAL
    result = await lookup(context, goal.query, deadline, include_visual=required, goal=goal)
    state.update(lookup_complete=True, status=result['status'], elapsed_ms=(monotonic() - started) * 1000)
    if result['status'] == 'matched' and result.get('required_visual_evidence') and not required:
        # The optional fast lookup excludes questions that require checking original images.
        state.update(status='visual_candidate_deferred', seed_block='本轮可选题库准备已结束，未采用需要原图核对的候选。直接原创完成，不声称采用了题库原题，不为添加出处再查库。')
        return state['seed_block']
    if result['status'] == 'matched':
        visual = result.get('model_message')
        if visual:
            from deeptutor.runtime.agentic.messages import extend_transient_model_messages
            evidence = context.extension('source_visual_evidence')
            extend_transient_model_messages(evidence.setdefault('model_messages', []), [{**visual, '_teaching_image': True}])
        block = (goal.preview_policy + '\n' + '本轮已读取下列完整题库原题及列出的必要原图。优先直接使用适合当前要求的原题，不必为了出题改编或再生成。'
                 '保持完整题干、选项、子题和条件；明确要求题库时不合适就继续查找，普通出题可明确标注原创，不把原创冒称库中原题。'
                 '需要多题但当前只有一题时，可继续读取；基础筛查不是答案核验。不得依据章名猜学生年级，其他年级或未标年级的内容须先判断适用性。实际使用时带给出的来源链接。\n'
                 + BANK_ADOPTION + '\n' + result['seed_block'])
        if required:
            block = '学生明确要求题库出题，不是在作答上一道题，也不是要求改从教材选题。使用实际读取的题库原题及其来源链接；已打开的教材仅作讲解参考，不能替代题库题源。不适合时继续查找，不自行改编或原创替代。\n' + block
        await stream.sources(result['sources'], source=source, stage=stage, metadata={'question_bank': True, 'retrieval_ms': state['elapsed_ms']})
    elif result['status'] == 'no_match' and only_originals(context, goal.source_request):
        block = ONLY_ORIGINALS_NOTICE
    elif required:
        notice = ('已完成本轮题库检索，未找到符合当前条件的可用原题。'
                  if result['status'] == 'no_match' else '本轮题库原题暂未能读取完成。')
        block = notice + ('先简短说明没有合适原题，再明确标注原创完成学生的出题要求，不编造题库出处。'
                          if result['status'] == 'no_match' else
                          '简短说明本轮题库查找尚未完成，不能据此说库中没有题。保留题库要求，不改从教材或原创替代，不暗中重试。')
    elif result['status'] != 'no_match':
        block = INCOMPLETE_RESOURCE_LOOKUP
    else:
        block = '本轮可选题库查找已结束。按完整原题要求直接原创完成，不为添加出处再自动查库，不声称原创题来自题库。'
    state['seed_block'] = block
    return block
