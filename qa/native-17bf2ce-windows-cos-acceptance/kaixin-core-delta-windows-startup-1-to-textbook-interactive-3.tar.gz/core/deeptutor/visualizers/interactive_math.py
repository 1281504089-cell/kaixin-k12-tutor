"""Turn compact parameter data into dependent GeoGebra objects locally."""

import json
import math
import re

from .curriculum_diagrams import CURRICULUM_INTERACTIVE
from .static_math import math_expression, number

QUADRATIC_LESSON = {
    "title": "可拖动的二次函数",
    "description": "初始图像为 y=x²。拖动 h、k 平移抛物线，拖动 a 改变开口宽窄，拖动 s 在向上与向下开口之间切换。",
    "view": [-8, 8, -10, 10],
    "parameters": [
        {"name": "h", "min": -4, "max": 4, "step": 0.5, "value": 0},
        {"name": "k", "min": -5, "max": 5, "step": 0.5, "value": 0},
        {"name": "a", "min": 0.25, "max": 2, "step": 0.25, "value": 1},
        {"name": "s", "min": -1, "max": 1, "step": 2, "value": 1},
    ],
    "functions": [{"name": "f", "expression": "s*a*(x-h)**2+k"}],
    "points": [{"name": "V", "xy": ["h", "k"]}],
}


INTERACTIVE_EXAMPLES = {
    "二次函数": QUADRATIC_LESSON,
    "一次函数": {
        "title": "一次函数的斜率和截距",
        "description": "拖动 m 改变斜率，拖动 b 改变纵截距。m=0 时对照观察水平直线。",
        "view": [-6, 6, -8, 8],
        "parameters": [
            {"name": "m", "min": -3, "max": 3, "step": 0.5, "value": 2},
            {"name": "b", "min": -4, "max": 4, "step": 0.5, "value": 0},
        ],
        "functions": [{"name": "f", "expression": "m*x+b"}],
        "points": [{"name": "P", "xy": ["0", "b"]}],
    },
    "反比例函数": {
        "title": "反比例函数的两支曲线",
        "description": "拖动 a 改变开口大小，拖动 s 切换两支曲线所在的象限。两支曲线始终与坐标轴不相交。",
        "view": [-6, 6, -6, 6],
        "parameters": [
            {"name": "a", "min": 0.5, "max": 4, "step": 0.5, "value": 2},
            {"name": "s", "min": -1, "max": 1, "step": 2, "value": 1},
        ],
        "functions": [{"name": "f", "expression": "s*a/x"}],
        "points": [{"name": "P", "xy": ["1", "s*a"]}],
    },
    "正弦函数": {
        "title": "正弦函数的振幅和上下平移",
        "description": "拖动 a 改变振幅，拖动 k 上下平移，中线经过 P。横轴单位为弧度。",
        "view": [-7, 7, -5, 5],
        "parameters": [
            {"name": "a", "min": 0.5, "max": 3, "step": 0.5, "value": 1},
            {"name": "k", "min": -2, "max": 2, "step": 0.5, "value": 0},
        ],
        "functions": [{"name": "f", "expression": "a*sin(x)+k"}],
        "points": [{"name": "P", "xy": ["0", "k"]}],
    },
    "简谐运动": {
        "title": "简谐运动的振幅与周期",
        "description": "拖动 A 改变振幅，拖动 T 改变周期。横轴为时间（秒），纵轴为位移（厘米）。",
        "view": [0, 6, -4, 4],
        "parameters": [
            {"name": "A", "min": 0.5, "max": 3, "step": 0.5, "value": 2},
            {"name": "T", "min": 1, "max": 4, "step": 0.5, "value": 2},
        ],
        "functions": [{"name": "f", "expression": "A*sin(2*pi*x/T)"}],
        "points": [{"name": "P", "xy": ["T/4", "A"]}],
    },
    **CURRICULUM_INTERACTIVE,
}

_RELATIVE_DRAW_WORDS = re.compile(
    r"呃|嗯|那|你|请|我想|我要|把|给我|来|换成|改成|做成|做|画|生成|出|一个|一张|一幅|张|个|动态|交互|"
    r"可以|可|被我|能不能|能|让我|拖动|移动|拖拽|拖一拖|的|这张|这条|这个|那条|上一张|刚才|上面|图[像象]?|演示|吗|呢|吧|一下|帮我|[\s，,。！？!?]"
)
_NAMED_FUNCTION = re.compile(r"二次函数|一次函数|抛物线")


def relative_interactive_request(text):
    from deeptutor.services.student_learning.study_preferences import interactive_figure_requested

    return len(text) <= 100 and interactive_figure_requested(text) and not _RELATIVE_DRAW_WORDS.sub("", text)


def explicit_parameter_graph(request):
    """Use the complete stated function, slider and points without filling in missing conditions."""
    from .function_plot import _LITERAL, expression, normalize, source_check

    if len(request) > 500:
        return None
    text = normalize(request).strip()
    match = re.fullmatch(
        rf"(?:(?:请你?|帮我|能不能)\s*)*(?:画(?:出)?|绘制|做(?:出)?|生成|给我)\s*(?:一[张幅个]\s*)?"
        rf"(?:动态|交互|可拖动的)(?:函数)?图[像象]?\s*[:：]?\s*y\s*=\s*(?P<formula>[A-Za-z0-9.()+*/\- \t]+)"
        rf"\s*[,。;]\s*(?:让我|可以|用滑块)?\s*(?:拖动|拖拽|调节)\s*(?P<name>[A-Za-z])"
        rf"\s*[,。;]\s*(?P=name)\s*(?:从|范围(?:为|是|:)?\s*\[?)\s*(?P<min>{_LITERAL})\s*(?:到|至|~|,)\s*(?P<max>{_LITERAL})\s*\]?"
        rf"\s*[,。;]\s*(?:步长|每步)\s*(?:为|是|:|=)?\s*(?P<step>{_LITERAL})"
        rf"\s*[,。;]\s*(?:初始|默认)(?:值)?\s*(?P=name)\s*=\s*(?P<initial>{_LITERAL})(?P<tail>.*)",
        text, re.DOTALL,
    )
    if not match:
        return None
    name = match["name"]
    lower, upper, step, initial = (float(match[key]) for key in ("min", "max", "step", "initial"))
    if name in {"x", "y", "z", "e"} or not -1e6 <= lower <= initial <= upper <= 1e6 or not 0 < step <= upper - lower:
        return None
    count = (upper - lower) / step
    if not 1 <= count <= 80 or not math.isclose(count, round(count)) or not math.isclose((initial - lower) / step, round((initial - lower) / step)):
        return None
    points = []
    for clause in re.split(r"[。;!?\n]", match["tail"]):
        clause = clause.strip(" ,.")
        clause = re.sub(r"^(?:只|仅)画(?:这)?一?条曲线(?:\s*[,、]\s*|$)", "", clause, count=1)
        if not clause:
            continue
        marked = re.fullmatch(r"(?:并)?标(?:出|注|明)\s*(.+)", clause)
        if not marked:
            return None
        rest = marked[1]
        while rest:
            point = re.match(r"(原点|点)?\s*([A-Z][0-9]?)\s*\(\s*([A-Za-z0-9.+*/\- ]+)\s*,\s*([A-Za-z0-9.+*/\- ]+)\s*\)", rest)
            if not point:
                return None
            kind, label, px, py = point.groups()
            if kind == "原点" and any(not re.fullmatch(r"[+-]?0+(?:\.0+)?", value.strip()) for value in (px, py)):
                return None
            points.append((label, px, py))
            rest = rest[point.end():].strip()
            if rest:
                separator = re.match(r"(?:和|与|及|、|,)\s*(?=\S)", rest)
                if not separator:
                    return None
                rest = rest[separator.end():]
    if len(points) > 6 or len({label for label, *_ in points}) != len(points):
        return None
    formula = expression(match["formula"], name)
    if len(formula) > 80 or not re.search(rf"\b{re.escape(name)}\b", formula):
        return None
    landmarks_x, landmarks_y = [-3, 3], [-1, 1]
    try:
        source_check(text, formula, (name, lower, upper, step, initial), points)
        for index in range(round(count) + 1):
            variables = {name: round(lower + index * step, 12)}
            evaluate = math_expression(formula, variables)
            for _, x, y in points:
                px = number(math_expression(expression(x, name), variables)(None))
                py = number(math_expression(expression(y, name), variables)(None))
                if not math.isclose(number(evaluate(px)), py, rel_tol=1e-8, abs_tol=1e-8):
                    return None
                landmarks_x.append(px)
                landmarks_y.append(py)
            for x in (-2, 0, 2):
                landmarks_y.append(number(evaluate(x)))
    except (ArithmeticError, SyntaxError, TypeError, ValueError):
        return None
    view = [min(landmarks_x) - 1, max(landmarks_x) + 1, min(landmarks_y) - 1, max(landmarks_y) + 1]
    if any(abs(value) > 1e6 for value in view):
        return None
    title_formula = formula.replace("**2", "²").replace("**3", "³").replace("**", "^").replace("*", "·")
    return {
        "title": f"参数函数 y={title_formula}",
        "description": f"拖动 {name}，观察曲线和标记点。范围 {lower:g} 到 {upper:g}，步长 {step:g}，初始值 {initial:g}。",
        "view": view,
        "parameters": [{"name": name, "min": lower, "max": upper, "step": step, "value": initial}],
        "functions": [{"name": "g" if name == "f" else "f", "expression": formula}],
        "points": [{"name": label, "xy": [expression(x, name), expression(y, name)]} for label, x, y in points],
    }


def polynomial_interactive_example(context):
    """Instantiate a verified parameterized function using the stated example."""
    from deeptutor.services.student_learning.reference_task_policy import student_request
    from deeptutor.services.student_learning.study_preferences import interactive_figure_requested, teaching_figure_requested
    from .function_plot import explicit_polynomial, normalize, polynomial_coefficients

    request = student_request(context)
    if not interactive_figure_requested(request) or not teaching_figure_requested(context):
        return None
    if explicit := explicit_parameter_graph(request):
        return explicit
    formula_pattern = re.compile(r"(?<![a-zA-Z0-9_])y\s*=\s*([x\d.*+\-\t ]+)(?=$|[\u3400-\u9fff$，,。.;；:：!！?？\])）\n])")
    text = normalize(request)
    formulas = set(formula_pattern.findall(text))
    named_followup = _NAMED_FUNCTION.search(request) if re.search(r"这个|这条|那条|刚才|上面", request) else None
    if formulas:
        remainder = formula_pattern.sub("", text)
        if re.search(r"\d|给定|指定|范围|步长|固定|只(?:拖|调|动)|仅|坐标范围|经过|交点|零点|添加|改参数|原题|原图", remainder):
            return None
    elif relative_interactive_request(request) or (
            named_followup and relative_interactive_request(_NAMED_FUNCTION.sub("", request))):
        # Only use an unambiguous function from the immediately preceding answer.
        last = context.conversation_history[-1] if context.conversation_history else {}
        previous = last.get("content")
        if last.get("role") != "assistant" or not isinstance(previous, str):
            return None
        prior_request = next((row.get("content", "") for row in reversed(context.conversation_history[:-1])
                              if row.get("role") == "user" and not row.get("_context_snapshot")), "")
        if not isinstance(prior_request, str) or re.search(r"范围|步长|固定|标出|标明|经过|交点|原题|原图|只(?:拖|调|动)", prior_request):
            return None
        reviewed = last.get("_reviewed_figure") or {}
        source = reviewed.get("title") if reviewed else previous
        formulas = set(formula_pattern.findall(normalize(source or "")))
    if len(formulas) != 1:
        return None
    formula = formulas.pop().strip()
    static = explicit_polynomial(f"画函数 y={formula} 的图像")
    if static is None:
        return None
    c, b, a = polynomial_coefficients(static["expression"])
    if named_followup:
        expects_quadratic = named_followup[0] != "一次函数"
        if bool(a) != expects_quadratic:
            return None
    if not (a or b) or not all(abs(coefficient) <= 10000 for coefficient in (a, b, c)):
        return None
    if a and abs(a) < 1e-4:
        return None
    parameters = []
    if a:
        low, high = sorted((a/4, a*2))
        parameters.append({"name": "a", "min": low, "max": high, "step": abs(a)/4, "value": a})
    coefficients = (("b", b), ("c", c)) if a else (("k", b), ("b", c))
    for name, value in coefficients:
        step = max(.25, round(abs(value)/4, 3))
        radius = 4 if a else max(4, math.ceil(abs(value) / step) + 2)
        parameters.append({"name": name, "min": value-radius*step, "max": value+radius*step, "step": step, "value": value})
    note = "" if a else " k=0 时对照观察水平线，此时不是一次函数。"
    return {
        "title": "二次函数的交互图" if a else "一次函数的交互图",
        "description": f"初始图像为 y={formula.replace('**2', '²').replace('*', '')}。拖动滑块，观察图像和标记点变化。" + note,
        "view": static["view"],
        "parameters": parameters,
        "functions": [{"name": "f", "expression": "a*x**2+b*x+c" if a else "k*x+b"}],
        "points": ([{"name": "V", "xy": ["-b/(2*a)", "c-b**2/(4*a)"]}] if a else []) + [{"name": "C", "xy": ["0", "c" if a else "b"]}],
    }


INTERACTIVE_RULES = """只返回严格JSON数据，不生成GeoGebra命令：
{"title":"中文图名","description":"中文操作说明和图形公式","view":[xmin,xmax,ymin,ymax],
"parameters":[{"name":"a","min":0.5,"max":2,"step":0.1,"value":1}],
"functions":[{"name":"f","expression":"a*x**2"}],
"points":[{"name":"V","xy":["0","0"]}]}。
所有数组都必需，没有则 []。参数最多4个，函数最多4条，关键点最多12个。
表达式只使用声明的参数名、x、数字、pi、e、+ - * / **、sin/cos/tan/sqrt/log/exp/abs。
关键点坐标表达式只能依赖参数，不能用未定义x。参数名、函数名和点名用唯一简短英文字母。
视图范围是有限数值，参数范围避开题目退化情形。完整保留所有原题条件，不猜测数值。
滑块、位置、中文界面与实时读数由本机实现，无需编写任何样式命令或文字控件。
"""


def build_interactive_math(data):
    parameters = data["parameters"]
    if not isinstance(parameters, list) or not 1 <= len(parameters) <= 4:
        raise ValueError("交互图需有1至4个明确参数")
    if not isinstance(data["functions"], list) or len(data["functions"]) > 4 or not isinstance(data["points"], list) or len(data["points"]) > 12:
        raise ValueError("交互图数据超过支持范围")
    names, values, commands = set(), {}, []
    def name(value):
        if not isinstance(value, str) or not re.fullmatch(r"[a-zA-Z][a-zA-Z0-9]{0,11}", value) or value in names or value in {"x", "y", "z", "pi", "e", "sin", "cos", "tan", "sqrt", "log", "exp", "abs"}:
            raise ValueError("交互图对象名无效或重复")
        names.add(value)
        return value
    for index, parameter in enumerate(parameters):
        key = name(parameter["name"])
        low, high, step, value = [number(parameter[field]) for field in ("min", "max", "step", "value")]
        if not low < high or not low <= value <= high or not 0 < step <= high-low:
            raise ValueError("无效滑块范围或初始值")
        values[key] = value
        commands.extend([f'{key}=Slider[{low},{high},{step},1,180,false,true,false,false]', f'SetValue[{key},{value}]', f'SetCoords[{key},30,{40+index*40}]', f'SetLabelMode[{key},1]'])
    functions = []
    for function in data["functions"]:
        key = name(function["name"])
        expression = function["expression"]
        math_expression(expression, values)
        commands.extend([f'{key}(x)={expression.replace("**", "^")}', f'SetLineThickness[{key},5]'])
        functions.append(expression)
    for point in data["points"]:
        key = name(point["name"])
        if not isinstance(point["xy"], list) or len(point["xy"]) != 2:
            raise ValueError("关键点必须有两个坐标表达式")
        coordinates = []
        for expression in point["xy"]:
            expression = str(expression)
            if re.search(r"\bx\b", expression):
                raise ValueError("关键点不能依赖未定义自变量x")
            math_expression(expression, values)
            coordinates.append(expression.replace("**", "^"))
        commands.extend([f'{key}=({",".join(coordinates)})', f'SetLabelMode[{key},1]', f'SetLabelVisible[{key},true]'])
    if not functions and not data["points"]:
        raise ValueError("交互图没有随参数变化的数学对象")
    view = dict(zip(("x_min", "x_max", "y_min", "y_max"), [number(value) for value in data["view"]], strict=True))
    return json.dumps({"app_name": "graphing", "commands": commands, "view": view}, ensure_ascii=False)
