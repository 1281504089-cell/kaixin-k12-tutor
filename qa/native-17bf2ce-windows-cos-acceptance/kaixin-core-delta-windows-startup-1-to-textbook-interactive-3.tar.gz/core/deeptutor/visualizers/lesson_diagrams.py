"""Renderer inputs for preview and review illustrations with explicitly chosen givens."""

from copy import deepcopy
import re

from .curriculum_diagrams import CURRICULUM_EXAMPLES, CURRICULUM_REVIEWED_SVG


EXAMPLES = (
    ("数轴", r"(?:有理数的)?数轴(?:上的正负数|与相反数)?", "number_line",
     {"values": [-2, -1, 0, 1, 2], "intervals": []}, "标 −2、−1、0、1、2，0 是原点，向右为正方向。"),
    ("不等式解集的数轴", r"一元一次不等式的解集.{0,8}数轴|数轴表示不等式的解集", "number_line",
     {"values": [], "intervals": [[-1, 2, True, False]]}, "示例解集 −1≤x<2，左端实心、右端空心。"),
    ("平面直角坐标系", r"平面直角坐标系(?:与点的坐标)?", "geometry",
     {"points": [["A", 2, 1], ["B", -2, 1], ["C", -2, -1], ["D", 2, -1], ["O", 0, 0]],
      "construct": [], "edges": [], "circles": [], "marks": [], "axes": True},
     "标 A(2,1)、B(−2,1)、C(−2,−1)、D(2,−1)，每个象限一个点，O 为原点。"),
    ("一次函数", r"(?:正比例|一次)函数(?:的?图[像象])?", "function",
     {"expression": "2*x", "view": [-3, 3, -6, 6], "points": [["O", "0", "0"], ["A", "1", "2"]], "slider": None},
     "例图取 y=2x，标 O(0,0) 和 A(1,2)。"),
    ("反比例函数", r"反比例函数(?:的?图[像象])?", "function",
     {"expression": "2/x", "view": [-5, 5, -5, 5], "points": [["A", "1", "2"], ["B", "-1", "-2"]], "slider": None},
     "画 y=2/x 的两支曲线，标 A(1,2)、B(−1,−2)，在 x=0 处断开。"),
    ("正弦函数", r"正弦(?:函数|曲线|波)(?:的?图[像象])?", "function",
     {"expression": "sin(x)", "view": [-7, 7, -2, 2], "points": [["O", "0", "0"]], "slider": None},
     "用 y=sin(x) 举例，横轴按弧度计算。"),
    ("二次函数", r"二次函(?:数|热)(?:y=x[²2]|的?图[像象])?|抛物线(?:的?图[像象])?", "function",
     {"expression": "x**2", "view": [-3, 3, -1, 10],
      "points": [["O", "0", "0"], ["A", "-2", "4"], ["B", "2", "4"]], "slider": None},
     "用 y=x² 举例，标顶点 O(0,0) 与对称点 A(−2,4)、B(2,4)。"),
    ("轴对称", r"轴对称(?:图形|变换)?", "geometry",
     {"points": [["A", 1, 2], ["B", 3, 1], ["C", 2, 4], ["O", 0, 0], ["P", 0, 5]],
      "construct": [[label + "′", "reflect", label, "O", "P"] for label in "ABC"],
      "edges": [[a, b, "solid"] for a, b in (("A", "B"), ("B", "C"), ("C", "A"),
                   ("A′", "B′"), ("B′", "C′"), ("C′", "A′"))] + [["O", "P", "dashed"]],
      "circles": [], "marks": [], "axes": False},
     "三角形 ABC 关于直线 OP 作轴对称，标对应顶点与对称轴。"),
    ("勾股定理", r"直角三角形(?:的三边关系)?|勾股定理", "geometry",
     {"points": [["A", 0, 0], ["B", 4, 0], ["C", 0, 3]], "construct": [],
      "edges": [["A", "B", "solid"], ["B", "C", "solid"], ["C", "A", "solid"]],
      "circles": [], "marks": [["right", "B", "A", "C"]], "axes": False},
     "用 A 为直角顶点的三角形示意两直角边和斜边，标顶点及直角。"),
    ("切线与割线", r"圆的斜切|圆的切线(?:[与和及]割线)?|切线[与和及]割线(?:的关系)?|切割线定理", "geometry",
     {"points": [["O", 0, 0], ["P", 13, 0], ["B", 4, -3]],
      "construct": [["A", "tangent", "P", "O", 5, "left"],
                    ["C", "line_circle", "P", "B", "O", 5, "last"]],
      "edges": [["P", "A", "solid"], ["P", "B", "solid"], ["B", "C", "solid"], ["O", "A", "dashed"]],
      "circles": [["O", 5]], "marks": [["right", "O", "A", "P"]], "axes": False},
     "标出圆心 O、圆外点 P、切点 A 和割线先后经过的 B、C，直角记号表示 OA⊥PA。用图说明 PA²=PB·PC。"),
    ("空间向量", r"(?:三维|空间)向量(?:的意义|的共面关系|共面)?", "lesson_space_vectors", {},
     "从同一点 O 画出 a、b、c。a、b 共同确定一个平面，c 在该平面外。用虚线补出平行四边形，无具体长度。"),
    ("长方体", r"长方体(?:的?(?:立体图|三视图))?", "solid",
     {"vertices": [["A", 0, 0, 0], ["B", 3, 0, 0], ["C", 3, 2, 0], ["D", 0, 2, 0],
                   ["A1", 0, 0, 1], ["B1", 3, 0, 1], ["C1", 3, 2, 1], ["D1", 0, 2, 1]],
      "faces": [["A", "B", "C", "D"], ["A1", "B1", "C1", "D1"], ["A", "B", "B1", "A1"],
                ["B", "C", "C1", "B1"], ["C", "D", "D1", "C1"], ["D", "A", "A1", "D1"]],
      "aux": [], "view": "solid"}, "以一个长方体示意各棱与顶点。"),
    ("串并联对照", r"(?:两灯泡)?(?:串联[与和及]并联|串并联)(?:电路)?", "lamp_comparison",
     {"topology": "both", "lesson": True}, "两灯串联与并联对照，同一节电池，干路开关以断开示意。"),
    ("串联电路", r"(?:两灯泡)?串联电路", "lamp_comparison",
     {"topology": "series", "lesson": True}, "用两个灯泡及一节电池示意串联，干路开关断开。"),
    ("并联电路", r"(?:两灯泡)?并联电路", "lamp_comparison",
     {"topology": "parallel", "lesson": True}, "用两个灯泡及一节电池示意并联，干路开关断开。"),
    ("光的反射", r"光的反射(?:定律)?|反射定律", "optics",
     {"kind": "reflection", "incidence": 35, "n1": None, "n2": None, "answers": True},
     "示例入射角 35°，绘入射光、反射光、法线、界面和相等的两角。"),
    ("光的折射", r"光的折射(?:规律)?", "optics",
     {"kind": "refraction", "incidence": 45, "n1": 1, "n2": 1.5, "answers": True},
     "空气射入玻璃，入射角 45°，折射率分别为 1、1.5，角都相对法线。"),
    ("凸透镜成实像", r"凸透镜成实像", "lens",
     {"focal": 10, "distance": 15, "height": 3, "answers": False},
     "示范焦外成实像，焦距 10 cm、物距 15 cm、物高 3 cm，画主光轴及两条特殊光线。"),
    ("凸透镜成像规律", r"凸透镜成像(?:规律)?", "lesson_lens_cases", {"focal": 10, "height": 3, "distances": [30, 20, 15, 10, 6]},
     "同一凸透镜焦距 10 cm，物高 3 cm。由远到近对照五种物距，标明实像、虚像或焦点处出射光平行。每幅图各画一条过光心和一条入射方向平行于主轴的光线。"),
    ("平面镜成像", r"平面镜成像(?:特点)?", "optical_image",
     {"kind": "mirror", "focal": None, "distance": 10, "height": 3, "calibration": None, "answers": True},
     "示例物距 10 cm、物高 3 cm。画平面镜、反射光、反向延长线及等大正立虚像。"),
    ("斜面受力", r"斜面(?:上物体的)?受力(?:分析)?", "incline",
     {"angle": 30, "state": "rest", "mass": None, "gravity": None, "answers": False},
     "物块静止于向右升高的粗糙 30° 斜面，无其他外力，画重力、支持力和沿斜面向上的静摩擦力。"),
    ("杠杆平衡", r"杠杆(?:的)?平衡(?:条件)?", "lever",
     {"left_arm": 0.2, "right_arm": 0.4, "left_force": 4, "answers": True},
     "例图左力臂 0.2 m、右力臂 0.4 m，左侧竖直向下 4 N，标支点和两侧作用力。"),
    ("匀变速运动速度图", r"匀变速直线运动(?:速度图[像象])?|速度[—－–-]时间图[像象]", "motion",
     {"kind": "velocity", "x0": 0, "v0": 1, "segments": [[3, 2, 7]]},
     "初速度 1 m/s，随后以 2 m/s² 匀加速 3 s，标速度轴、时间轴与单位。"),
    ("简谐运动", r"简谐(?:运动|振动)(?:图[像象])?", "periodic",
     {"kind": "oscillation", "unit": "cm", "end": 4, "traces": [["", 2, 2, 0]]},
     "例图振幅 2 cm、周期 2 s、正弦初相位为 0，展示两个周期的位移—时间图。"),
    ("频率分布直方图", r"频率分布直方图", "chart",
     {"kind": "histogram", "title": "频率分布直方图", "x_label": "成绩 / 分",
      "y_label": "频率/组距", "series": [["", [[60, 70, .2], [70, 80, .3], [80, 100, .5]]]]},
     "例图三组为 60–70、70–80、80–100 分，频率为 0.2、0.3、0.5，柱高为频率除以组距。"),
) + CURRICULUM_EXAMPLES


# Reuse review only for the rendered example that was checked.
REVIEWED_SVG = {
    "31d1d68877f79ad93a7e3411a5780702b3a135f9264dc54a8fa476a102375070": "01-number_line",
    "b615f0b3e1487902fe0cbe31f1550be95059d02262914e3be8eb32c9a70549cc": "02-number_line",
    "a84716a1b5745f65b8e469b272764231fc8f2313bb26cad4f6dc1558faadcf13": "03-geometry",
    "1c3dba16f2223eb7c28275a801242622fef12078af5e70ec198b011f35af03c8": "04-function",
    "d6f18108e996c28680c967d707f0e69bf79f2803a191c1c688d77ed80d7f9bcd": "05-function",
    "9fa957d708592aebf6f83af8d540c2b408041ce79ac51cb6008b678c36b76f79": "06-function",
    "2cd1e7f53be5c57c97ad3ae931e5b1b6582df1e9695229301f0c88074b886242": "07-geometry",
    "91f10fba2599db457b1184157b8fa56c643795a3a06ec890d5a8b1aaba8fffb2": "08-geometry",
    "84488b8a4bba1c12d6429611305c7a01f6c9ae6f1641da9f914de5ccfdee3828": "09-solid",
    "8734ed5610a529103c4761bc2ca8a93622fde12bc406efe6cd4a69a295b14660": "10-lamp_comparison",
    "152c313dd56557fadaafe9be13dab0047a06073510c834cf41680752cb9d73a1": "11-lamp_comparison",
    "24a0e7074d97e6cff9b014c64c58ca2fca77c8b27f44a3ffe02f80cad9ca0b1e": "12-optics",
    "58fc9f85462c3edf86771025e1ff460f6dbcc59f0e3b78516f621f7f9a5b2cae": "13-optics",
    "45f650a0d85ffbae5771514a5eb4db7ce507ea7442886b5e96c545e6cb2758fa": "14-lens",
    "f7904cb30fcdf3a3c9b6d31e024e6792a4186001f7b98cd2948ddef7420b7577": "15-lesson_lens_cases",
    "c91d481c0cddf5d696c0a4b0f79c8b9394a204f7f38ca967b854a48343571f4d": "16-optical_image",
    "5d0ee90f91714936bef5dc81555842a9be7795821f701ba98b0c06cded237ff6": "17-incline",
    "a4b48d1c6fe15332f40af478d76ac3ad108b4a08a81b29ec875e11f66fa73efe": "18-lever",
    "8880909e7af82f93a2f5556d7d7f93488e01c7a783c84e86f5ea798e6d419117": "19-motion",
    "87f768a0c5537575ec413e3006e78e5c2a079a1529114a38a669fd8450b4b242": "20-periodic",
    "d20ccf0588d4fc35b18c717e6e4cc7e556a5f6da8c009b12e560da417145e23d": "21-chart",
    "acd71e0762ed39ce075e1b1c074b90c32633ec8d548751ee64691fc751077774": "22-solid",
    "5deb3003f9b446014b5298b4c1041f1dae1a9f55cd715736908b395d51d265dd": "23-lamp_comparison",
    "adce011c3b7f8241c0cf7198d6bb53b0fd1f046675194d22d42c3cc5ee4f0ed1": "24-circle-tangent-secant",
    "1c73284c2153bab42df196224714e6b30565f5eac16f080659ee890a02025e03": "25-space-vector-coplanarity",
    "0015cadb45b35e36fdd46e090ba788a6d348bdeeceff541146e6f9224d6f39d0": "26-sine-function",
    **CURRICULUM_REVIEWED_SVG,
}


EXAMPLE_TOPICS = [title for title, *_ in EXAMPLES] + ["长方体三视图"]

# The available controls are properties of each checked example. Keep unknown
# properties in the residue so a narrower example cannot discard a requirement.
_INTERACTIVE_CONCEPTS = {
    "角的大小": (r"角的大小|角度|锐角|角", r"度数|大小|两边长短|取点(?:距离|远近)|张开程度"),
    "一次函数": (r"一次函[数热]|线性函数|斜率", r"斜率|截距"),
    "二次函数": (r"二次函[数热]|抛物线", r"开口(?:方向|大小)?|顶点|平移|宽窄"),
    "反比例函数": (r"反比例函数", r"开口(?:大小)?|象限|两支曲线"),
    "正弦函数": (r"正弦(?:函数|曲线|波)", r"振幅|上下平移|中线"),
    "指数函数": (r"指数函数", r"底数|大小|增减"),
    "对数函数": (r"对数函数", r"底数|大小|增减"),
    "简谐运动": (r"简谐(?:运动|振动)", r"振幅|周期|位移"),
    "匀变速运动速度图": (r"匀变速(?:直线)?运动|速度[—－–与-]时间(?:图[像象]?)?", r"加速度|速度|时刻"),
}
_INTERACTIVE_WORDS = re.compile(
    r"能不能|可不可以|能否|可以被我|可以|能让|想要|我想|我要|给我|帮我|直观地|直观|"
    r"做成|画成|绘制|生成|展示|演示|示意|想看|看看|看一下|观察|看|做|画|出|能|可|会|让|把|被我|我|"
    r"滑块|参数|动态|交互|互动|动起来|能动|移动|拖着|拖一拖|拖一下|拖动|拖拽|拖|"
    r"变大变小|变大小|变大|变小|怎么变化|怎么变|变化|改变|调整|调节|调一调|调一下|调|变|"
    r"那个|这个|那种|这种|一张|一个|一幅|张|个|图[像象形]?|吗|吧|呀|呢|一下|自己|一起|就|也|先|请|"
    r"的|再|和|与|用|成|[\s，,。！？!?；;]"
)


def interactive_lesson_topic(text):
    """Resolve a current concept only when all requested controls fit its example."""
    if len(text) > 100:
        return ""
    matches = []
    for title, (names, controls) in _INTERACTIVE_CONCEPTS.items():
        if re.search(names, text):
            remainder = re.sub(rf"(?:{names}|{controls})", "", text)
            if not _INTERACTIVE_WORDS.sub("", remainder):
                matches.append(title)
    return matches[0] if len(matches) == 1 else ""


def _space_vector_followup(context, drawing_task):
    brief = re.sub(r"[\s，、,]", "", drawing_task)
    if not re.search(r"空间向量|三维向量", brief) or not re.search(r"不一定共面|不共面|平面外|伸出", brief):
        return False
    if not all(re.search(item, brief) for item in (
        r"同一(?:个)?(?:点|原点)", r"平行四边形", r"a(?:=OA)?水平向右",
        r"b(?:=OB)?斜向右上", r"c(?:=OC)?竖直向上",
    )):
        return False
    if re.search(r"垂直|法向量|夹角|投影|数乘|数量积|坐标|\d", brief):
        return False
    return bool(re.fullmatch(
        r"(?:请|带我|帮我|先|我想|学习|学|讲讲|讲解|一下|预习|复习|\s)*(?:空间|三维)向量(?:的意义)?[。！!\s]*", _last_student_message(context)))


def _last_student_message(context):
    history = context.conversation_history
    side = (context.metadata.get("side_chat_context") or {}).get("conversation_messages", [])
    for row in reversed([*side, *history]):
        if row.get("role") == "user" and not row.get("_context_snapshot"):
            content = row.get("content")
            return content if isinstance(content, str) else ""
    return ""


def lesson_diagram(context, *, example_topic="", drawing_task="", interactive=False):
    from dataclasses import replace

    from deeptutor.services.student_learning.reference_task_policy import _readable_source, _text, reference_task_policy, student_request
    from deeptutor.services.student_learning.study_preferences import (
        _PREPARE, asks_to_explain_current_problem, interactive_figure_requested, short_drawing_request,
        teaching_figure_excluded, teaching_figure_requested,
    )
    from .figure_sources import _GIVENS
    from .interactive_math import INTERACTIVE_EXAMPLES, polynomial_interactive_example, relative_interactive_request

    text = _text(student_request(context))
    has_problem = any(item.type not in {"quote", "library_reference"} for item in context.attachments)
    evidence = context.extension_state.get("source_visual_evidence", {})
    relative_interactive = interactive and (relative_interactive_request(text) or (
        bool(re.search(r"这个|这张|刚才|上一张|拖着看|拖一拖", text))
        and not _INTERACTIVE_WORDS.sub("", re.sub(r"刚才|上一张|这张", "", text))
    ))
    last = context.conversation_history[-1] if context.conversation_history else {}
    previous_figure = last.get("_reviewed_figure") if last.get("role") == "assistant" else None
    relative_to_chat_figure = relative_interactive and previous_figure and not (
        _readable_source(context) or any(context.metadata.get(k) for k in ("book_references", "reading_references", "catalog_source_references"))
    )
    if ((reference_task_policy(context).mode != "related_only" and not relative_to_chat_figure) or teaching_figure_excluded(context)
            or context.metadata.get("has_problem_attachments", has_problem) or has_problem
            or evidence.get("selected_question_text") or evidence.get("verified_study_followup")
            or asks_to_explain_current_problem(text)
            or not interactive and interactive_figure_requested(text)):
        return None

    if interactive and (polynomial := polynomial_interactive_example(context)):
        return ("geogebra", polynomial), polynomial["description"], True

    short = short_drawing_request(text)
    requested = teaching_figure_requested(context)
    vector_followup = short and not interactive and _space_vector_followup(context, drawing_task)
    if vector_followup:
        example_topic = "空间向量"
    current_topic = interactive_lesson_topic(text) if interactive else ""
    current_request = bool(current_topic and requested)
    condition_text = text if current_request or relative_interactive else f"{text}\n{drawing_task}"
    conditions = re.sub(r"\d{1,2}\s*年级|\by\s*=\s*x²(?![+−-])", "", condition_text)
    if (not vector_followup and _GIVENS.search(conditions) or re.search(
        r"\d|原题|原图|给定|指定|限制|范围|步长|读数|交点|零点|对称轴|固定斜率|交换标签|改(?:成|为)\s*[^，。]*[A-Z]",
        conditions,
    ) or not current_request and "改变周期" in conditions):
        return None
    if current_request:
        spec = INTERACTIVE_EXAMPLES[current_topic]
        return ("geogebra", deepcopy(spec)), spec["description"], True

    grade = r"(?:初[一二三]|高[一二三]|[一二三四五六七八九十1-9]年级|小学|初中|高中)"
    prefix = (
        r"^(?:(?:那你?|请你?|能不能|可以|帮我|带我|我想|我要|给我|让我|直接|就|只|先|现在|接着|再|来|一起)\s*)*"
    )
    prep = _PREPARE.match(text) or re.match(prefix + r"(?:学一学|学习?|教我|讲解|讲讲|讲一下)\s*(?:一下)?\s*", text)
    draw = re.match(
        prefix + r"(?P<action>发我|画(?:出|一下)?|绘制|作出|出|展示|看看|看一下|给我|来)\s*"
        r"(?:(?P<verb>画(?:出|一下)?|绘制|看看|看一下|看)\s*)?(?:一?[张个幅])?\s*",
        text,
    ) if not prep else None
    lead = prep or draw
    topic = text[lead.end():].strip(" 。！？!?\t") if lead else text.rstrip("。！？!?")
    topic = re.sub(rf"^[，,\s]*(?:我是)?{grade}[，,\s]+|[，,\s]+(?:我是)?{grade}$", "", topic).strip()
    topic = re.sub(r"(?:给我看|看一下|看看|可以吗|好吗|[吧吗呀呢])$", "", topic).strip()
    topic = re.sub(r"\s*(?:[，,]\s*(?:并|且|同时|顺便)?|并|且|同时|顺便)\s*(?:帮我)?\s*(?:配(?:一张)?图|画(?:一张)?图|带上示意图)$", "", topic)
    subject = re.sub(r"(?:的)?(?:示意图|图例|图[像象形]|图)$", "", topic).strip()
    task_topic = re.sub(r"^(?:画(?:一[张个]|[张个])?|绘制|展示)\s*|(?:的)?(?:示意图|图例|图)$",
                        "", _text(drawing_task)).strip()
    described = bool(example_topic or drawing_task and _text(drawing_task) != text)
    if draw and draw["action"] in {"给我", "发我", "来", "出"} and not (
        (draw["verb"] or "").startswith(("画", "绘制")) or subject != topic or requested
    ):
        return None

    example_title = "长方体" if example_topic == "长方体三视图" else example_topic
    if short and not vector_followup or relative_interactive:
        # A follow-up can inherit a recent concept example, but never an older or unsolved problem.
        previous = _last_student_message(context)
        if relative_interactive and re.search(r"图.{0,24}(?:来源|从哪|命中|图(?:形)?库)", previous):
            students = [row["content"] for row in context.conversation_history[-8:]
                        if row.get("role") == "user" and isinstance(row.get("content"), str)
                        and not row.get("_context_snapshot")]
            previous = next((value for value in reversed(students)
                             if not re.search(r"图.{0,24}(?:来源|从哪|命中|图(?:形)?库)", value)), "")
        if previous and not short_drawing_request(previous):
            prior_context = replace(context, raw_user_message=previous, user_message=previous,
                                    conversation_history=[], metadata={})
            prior = lesson_diagram(prior_context)
            if prior:
                prior_family, prior_spec = prior[0]
                title = next((label for label, _, family, spec, _ in EXAMPLES
                              if (family, spec) == (prior_family, prior_spec)), "")
                if short and not interactive and (not described or example_title == title or any(
                    label == title and re.fullmatch(pattern, task_topic) for label, pattern, *_ in EXAMPLES
                )):
                    return prior[0], prior[1], True
                if relative_interactive and title in INTERACTIVE_EXAMPLES:
                    spec = INTERACTIVE_EXAMPLES[title]
                    return ("geogebra", deepcopy(spec)), spec["description"], True
        if short or relative_interactive:
            return None

    if not (lead or described or requested):
        return None
    if interactive and requested and not relative_interactive:
        # A named request with unmatched controls needs the full drawing path.
        return None
    for title, pattern, family, parameters, task in EXAMPLES:
        matched = title == example_title if example_title else (
            title == topic or re.fullmatch(pattern, topic) or re.fullmatch(pattern, subject) or re.fullmatch(pattern, task_topic)
            or interactive and interactive_figure_requested(text) and re.search(rf"(?:{pattern})", text)
        )
        if not matched:
            continue
        if interactive:
            spec = INTERACTIVE_EXAMPLES.get(title)
            if spec is not None:
                return ("geogebra", deepcopy(spec)), spec["description"], requested and not prep
            return None
        if not family:
            return None
        spec = deepcopy(parameters)
        if family == "solid" and "三视图" in (example_topic or topic or task_topic):
            spec["view"] = "three"
            task = "以同一个长方体示意主视图、俯视图和左视图。"
        return (family, spec), "用于" + text + "的教学例图（例图参数由系统选定）。" + task, draw is not None
    return None


def space_vector_example(_spec):
    from math import hypot

    from .school_diagrams import BLUE, ORANGE, Drawing
    from .textbook_math_school import polygon

    origin, a, b, c = (164, 260), (516, 260), (285, 169), (164, 92)
    opposite = (a[0] + b[0] - origin[0], a[1] + b[1] - origin[1])
    drawing = Drawing("空间向量与共面", "a、b 位于同一平面，c 从 O 伸出这个平面。示意图无长度或角度刻度。", height=350)
    polygon(drawing, [origin, a, opposite, b], fill="#e7f2fc", color="#e7f2fc")
    drawing.line(a, opposite, b, color=BLUE, width=2, dashed=True)
    drawing.text((452, 225), "a、b 所在的平面", color=BLUE, size=17)
    for endpoint, tag, tag_at, label, label_at, color in (
        (a, "a", (340, 289), "A", (527, 265), BLUE),
        (b, "b", (208, 208), "B", (288, 152), BLUE),
        (c, "c", (144, 162), "C", (164, 74), ORANGE),
    ):
        x, y = endpoint
        dx, dy = x - origin[0], y - origin[1]
        length = hypot(dx, dy)
        ux, uy = dx / length, dy / length
        tail = (x - 12 * ux, y - 12 * uy)
        drawing.line(origin, tail, color=color, width=3.2)
        polygon(drawing, [endpoint, (tail[0] - 4.5 * uy, tail[1] + 4.5 * ux),
                          (tail[0] + 4.5 * uy, tail[1] - 4.5 * ux)], fill=color, color=color)
        drawing.text(tag_at, tag, color=color, size=22)
        drawing.text(label_at, label, color=color, size=19)
    drawing.dot(origin)
    drawing.text((149, 284), "O", size=19)
    drawing.text((380, 325), "a、b 共面，c 不在该平面内", size=17)
    return drawing


def lens_cases(spec):
    from .school_diagrams import Drawing
    from .textbook_physics_extended import optical_image

    focal, height = spec["focal"], spec["height"]
    distances = spec["distances"]
    if len(distances) != 5 or not (distances[0] > 2*focal == distances[1] > distances[2] > focal == distances[3] > distances[4]):
        raise ValueError("凸透镜对照需覆盖二倍焦距内外与焦点内外")
    captions = ("u > 2f　倒立缩小实像", "u = 2f　倒立等大实像", "f < u < 2f　倒立放大实像",
                "u = f　出射光平行", "u < f　正立放大虚像")
    drawing = Drawing("凸透镜成像五种情况", "焦距与物高相同，每幅图均单独缩放，虚线为反向延长线。", height=1240)
    for index, (distance, caption) in enumerate(zip(distances, captions)):
        example = optical_image({"kind": "convex", "focal": focal, "distance": distance, "height": height,
                                 "calibration": None, "answers": True})
        y = 60+index*231
        drawing.text((72, y+24), caption, size=19, align="start")
        drawing.parts.append(f'<g transform="translate(115,{y+23}) scale(.52)">' + "".join(example.parts) + "</g>")
    return drawing
